# jQuery.filer was transferred to <a href="https://innostudio.de/fileuploader/"><b>Fileuploader 2.2</b></a>

<a href="https://innostudio.de/fileuploader/"><img src="https://innostudio.de/fileuploader/preview2.2.jpg" alt="jquery file upload plugin"></a>
